﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoprijonokApp
{
    public partial class Form1 : Form
    {
        Model1 db = new Model1();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            agentBindingSource.DataSource = db.Agent.ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            agentBindingSource.DataSource = db.Agent.Where(a => a.Title.Contains(textBox1.Text) || a.DirectorName.Contains(textBox1.Text)).ToList();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Приоритет")
            {
                agentBindingSource.DataSource = db.Agent.OrderBy(a => a.Priority).ToList();
            }
            if (comboBox1.Text == "ИНН")
            {
                agentBindingSource.DataSource = db.Agent.OrderBy(a => a.INN).ToList();
            }
            if (comboBox1.Text == "КПП")
            {
                agentBindingSource.DataSource = db.Agent.OrderBy(a => a.KPP).ToList();
            }
            if (comboBox1.Text == "Вернуть исходные значения")
            {
                agentBindingSource.DataSource = null;
                agentBindingSource.DataSource = db.Agent.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Agent agn = (Agent)agentBindingSource.Current;
            DialogResult dr = MessageBox.Show("Удалить запись?" + agn.ID +"'"+ agn.Title + "'" + "?", "Удаление записи", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                db.Agent.Remove(agn);
            }
            try
            {
                db.SaveChanges();
                agentBindingSource.DataSource = db.Agent.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.agn = null;
            DialogResult agn = f2.ShowDialog();
            if (agn == DialogResult.OK)
            {
                agentBindingSource.DataSource = db.Agent.ToList();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();

            Agent agn = (Agent)agentBindingSource.Current;
            f3.agn = null;
            DialogResult dr = f3.ShowDialog();
            if (dr == DialogResult.OK )
            {
                agentBindingSource.DataSource = db.Agent.ToList();
            }
        }
    }
}
