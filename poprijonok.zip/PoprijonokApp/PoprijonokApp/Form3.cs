﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoprijonokApp
{
    public partial class Form3 : Form
    {
        public static Model1 db { get; set; }
        public Agent agn { get; set; }
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            titleTextBox.Text = agn.Title;
            agentTypeIDTextBox.Text = agn.AgentTypeID.ToString();
            addressTextBox.Text = agn.Address;
            iNNTextBox.Text = agn.INN;
            kPPTextBox.Text = agn.KPP;
            directorNameTextBox.Text = agn.DirectorName;
            phoneTextBox.Text = agn.Phone;
            emailTextBox.Text = agn.Email;
            logoTextBox.Text = agn.Logo;
            priorityTextBox.Text = agn.Priority.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (titleTextBox.Text == "" || agentTypeIDTextBox.Text == "" || iNNTextBox.Text == "" || phoneTextBox.Text == "" || priorityTextBox.Text == "")
            {
                MessageBox.Show("Пожалуйста, введите все обязательные данные");
                return;
            }

            int agt;
            bool a = int.TryParse(agentTypeIDTextBox.Text, out agt);
            if (a == false)
            {
                MessageBox.Show("Неверный тип данных Agent Type ID, п");
                return;
            }

            int pror;
            bool b = int.TryParse(priorityTextBox.Text, out pror);
            if (b == false)
            {
                MessageBox.Show("Неверный тип данных Priority, п");
                return;
            }

            Agent agn = new Agent();

            agn.Title = titleTextBox.Text;
            agn.AgentTypeID = agt;
            agn.Address = addressTextBox.Text;
            agn.INN = iNNTextBox.Text;
            agn.KPP = kPPTextBox.Text;
            agn.DirectorName = directorNameTextBox.Text;
            agn.Phone = phoneTextBox.Text;
            agn.Email = emailTextBox.Text;
            agn.Logo = logoTextBox.Text;
            agn.Priority = pror;

            try
            {
                db.SaveChanges();

                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
